How to execute:
The program is written in Python 2.7.
The figure is drawn using the package “matplotlib.pyplot”, see http://matplotlib.org/users/installing.html to install this package.
Execute “executable”, then assign color number and node number.
If running into problem when executing “executable”, please execute “mapColoring.py”.
————————————————————————————————————————————————————————————————————————————————————
Instructions:
The output of one run is one figure of uncolored map, close the figure and the colored map using MRV algorithm will show up. Then close the MRV colored figure and colored map using ARC will show up. Then close the ARC colored figure and colored map using buckjumping will show up.