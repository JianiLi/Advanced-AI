How to run:Run sixteenPuzzle.py and choose the No. for configuration, heuristic function and search algorithm.

