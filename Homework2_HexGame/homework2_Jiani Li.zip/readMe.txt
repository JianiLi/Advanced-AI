This program is written in Python 2.7

In the folder”codes”, run main.py and choose mode to play hex game.

